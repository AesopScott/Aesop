# aesopacademy.org — File Map
> **Domain root:** `public_html/aesop-academy/` on the shared cPanel account (tech2table.com / hivetec1).
> Everything below is relative to that folder. `aesopacademy.org/` maps to `public_html/aesop-academy/`.

---

## CRITICAL RULE: Never save any file locally as `index.html`.
Local filenames must always be descriptive and versioned. Only the server gets `index.html`.
FTP clients let you rename on upload — use that feature every time.

---

## The Golden Rule

```
LOCAL NAME                              →   FTP AS (path from public_html/aesop-academy/)
aesop-academy-root-index.html           →   index.html
ai-academy-index-vX.X.X.html           →   ai-academy/index.html
mN-intro-vX.html                        →   ai-academy/modules/module-N/intro.html
mN-basic-vX.html                        →   ai-academy/modules/module-N/basic.html
mN-advanced-vX.html                     →   ai-academy/modules/module-N/advanced.html
```

---

## Three Tiers

| Tier | Internal name | FTP filename | Group ID | Chip label | Accent |
|------|--------------|--------------|----------|------------|--------|
| Introduction to AI Foundations & Youth Education | `intro` | `intro.html` | 1 | ⭐ Introduction | #fbbf24 |
| Basic AI Foundations & Young Adult Education | `basic` | `basic.html` | 2 | 🔬 Basic | #c084fc |
| Advanced AI Foundations & Adult Education | `advanced` | `advanced.html` | 3 | 🎯 Advanced | #f43f5e |

---

## Cross-domain link rule

`aesopacademy.org` and `playagame.ai` are separate deployments on the same cPanel account.
**Never use relative paths to cross domains.** Always use full `https://` URLs.

| Linking from | Linking to | Use |
|---|---|---|
| `aesopacademy.org` | `playagame.ai` | `https://playagame.ai/...` |
| `playagame.ai` | `aesopacademy.org` | `https://aesopacademy.org/...` |

---

## Site Root

| ⚠️ NEVER save locally as | ✅ Local filename | FTP destination | Live URL |
|---|---|---|---|
| `index.html` | `aesop-academy-root-index.html` | `index.html` | `aesopacademy.org/` |

---

## /ai-academy/

| ⚠️ NEVER save locally as | ✅ Local filename | FTP destination | Live URL |
|---|---|---|---|
| `index.html` | `ai-academy-index-vX.X.X.html` | `ai-academy/index.html` | `aesopacademy.org/ai-academy/` |
| *(already unique)* | `AESOP-AI-Academy-Prospectus.html` | `ai-academy/AESOP-AI-Academy-Prospectus.html` | `aesopacademy.org/ai-academy/AESOP-AI-Academy-Prospectus.html` |

### Firebase auth status
| File | Firebase patch |
|---|---|
| `ai-academy/index.html` | ✅ Auth ported (v2.0.15+); modules beyond Module 1 gated behind login |

### Current version
`ai-academy-index-v1.0.1.html` — 3-tier architecture (Introduction / Basic / Advanced). 10-module layout, 3-col (480px nav | 1fr content | 300px reward pane). Lesson content loaded from `/ai-academy/modules/module-N/{tier}.html`.

---

## /ai-academy/modules/

**Architecture:** 3 tiers × 10 modules = 30 lesson files total.
All modules available to all tiers. Lesson count by tier: Introduction=4, Basic=6, Advanced=8.

**Naming convention:** `intro.html`, `basic.html`, `advanced.html`

**Completion signaling:** Lesson files post completion to nav via:
`window.parent.postMessage({ type:'lessonComplete', lessonId:'m1-l1', groupId: GROUP_ID }, '*')`

---

### /ai-academy/modules/module-1/ — What Is AI?

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m1-intro-vX.html` | `ai-academy/modules/module-1/intro.html` | Introduction | L1–L4 | ✅ Built |
| `m1-basic-vX.html` | `ai-academy/modules/module-1/basic.html` | Basic | L1–L6 | ✅ Built |
| `m1-advanced-vX.html` | `ai-academy/modules/module-1/advanced.html` | Advanced | L1–L8 | ✅ Built |

> **Archive note:** Old 6-group files (age-7-8, age-11-12, age-16plus, etc.) are archived. New builds use tier naming.

---

### /ai-academy/modules/module-2/ — AI in Our World

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m2-intro-vX.html` | `ai-academy/modules/module-2/intro.html` | Introduction | L1–L4 | ✅ Built |
| `m2-basic-vX.html` | `ai-academy/modules/module-2/basic.html` | Basic | L1–L6 | ✅ Built |
| `m2-advanced-vX.html` | `ai-academy/modules/module-2/advanced.html` | Advanced | L1–L8 | ✅ Built |

---

### /ai-academy/modules/module-3/ — Sometimes AI Gets It Wrong

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m3-intro-vX.html` | `ai-academy/modules/module-3/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m3-basic-vX.html` | `ai-academy/modules/module-3/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m3-advanced-vX.html` | `ai-academy/modules/module-3/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-4/ — Stories & Creativity with AI

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m4-intro-vX.html` | `ai-academy/modules/module-4/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m4-basic-vX.html` | `ai-academy/modules/module-4/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m4-advanced-vX.html` | `ai-academy/modules/module-4/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-5/ — Staying Safe with AI

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m5-intro-vX.html` | `ai-academy/modules/module-5/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m5-basic-vX.html` | `ai-academy/modules/module-5/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m5-advanced-vX.html` | `ai-academy/modules/module-5/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-6/ — How AI Learns

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m6-intro-vX.html` | `ai-academy/modules/module-6/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m6-basic-vX.html` | `ai-academy/modules/module-6/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m6-advanced-vX.html` | `ai-academy/modules/module-6/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-7/ — How AI Thinks

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m7-intro-vX.html` | `ai-academy/modules/module-7/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m7-basic-vX.html` | `ai-academy/modules/module-7/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m7-advanced-vX.html` | `ai-academy/modules/module-7/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-8/ — AI Ethics & Real Decisions

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m8-intro-vX.html` | `ai-academy/modules/module-8/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m8-basic-vX.html` | `ai-academy/modules/module-8/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m8-advanced-vX.html` | `ai-academy/modules/module-8/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-9/ — AI in Society, Law & the Future

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m9-intro-vX.html` | `ai-academy/modules/module-9/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m9-basic-vX.html` | `ai-academy/modules/module-9/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m9-advanced-vX.html` | `ai-academy/modules/module-9/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

---

### /ai-academy/modules/module-10/ — Careers, Research & Building with AI

| ✅ Local filename | FTP destination | Tier | Lessons | Status |
|---|---|---|---|---|
| `m10-intro-vX.html` | `ai-academy/modules/module-10/intro.html` | Introduction | L1–L4 | 🔲 Not built |
| `m10-basic-vX.html` | `ai-academy/modules/module-10/basic.html` | Basic | L1–L6 | 🔲 Not built |
| `m10-advanced-vX.html` | `ai-academy/modules/module-10/advanced.html` | Advanced | L1–L8 | 🔲 Not built |

**Total module files: 30** (3 tiers × 10 modules)

---

## /forums/

| ⚠️ NEVER save locally as | ✅ Local filename | FTP destination | Live URL |
|---|---|---|---|
| `index.html` | `aesop-academy-forums-index-vX.html` | `forums/index.html` | `aesopacademy.org/forums/` |

---

## Assets

| Server Path | Notes |
|---|---|
| `/og-image.jpg` | Open Graph / Twitter card image |

---

## Upload workflow — every single time

**Before FTPing anything:**
1. Download the current server file via cPanel first
2. Save it to `/archive/` with a date suffix e.g. `m1-intro-v15-2026-04-06.html`
3. Then FTP the new version

**After Claude delivers a file:**
1. Save it locally with the descriptive versioned name (e.g. `m1-intro-v15.html`)
2. FTP it to the server path using the target filename (e.g. `intro.html`)

---

## Off-limits files (never upload to Claude, never overwrite)

| File | Reason |
|---|---|
| `claude-proxy.php` | Manual edits: ini_set memory/post size, API key hardcoded |
| Any `/archive/` file | Old builds — leave alone |

---

## Reference documents (not deployed to server)

| Local filename | Purpose |
|---|---|
| `AESOP-Academy-Module-Standards.md` | Master standards doc — file naming, CSS, HTML patterns, JS block, narrative density rules, QA checklist |
| `AESOP-ACADEMY-FILE-MAP.md` | This file |

---

## Lesson file versioning rules

- Each file tracks its own version independently — no shared version numbers
- Bump the version on **every delivery**, even single-line changes
- Local file: `m1-intro-vX.html` → FTP as: `intro.html` in `/ai-academy/modules/module-1/`

---

*Last updated: 2026-04-06 — Rebuilt for 3-tier architecture. Retired 6-age-group system (47 files). New system: 3 tiers × 10 modules = 30 files. Tier names: intro / basic / advanced. FTP targets: intro.html / basic.html / advanced.html. Group IDs: 1=Introduction, 2=Basic, 3=Advanced. M1 and M2 all three tiers confirmed built.*
