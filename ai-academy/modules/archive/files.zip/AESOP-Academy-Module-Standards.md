# AESOP AI Academy — Module Lesson File Standards
## Reference document for building all modules and age groups

---

## 1. File Naming Convention

Each lesson file follows: `m{MODULE}-{TIER}-v{VERSION}.html`

- Module 1, Introduction tier, version 15: `m1-intro-v15.html`
- FTP to server as: `{tier}.html` in the appropriate module directory
- Versions are **per-file independent** — each file has its own version history
- **Bump the version on every delivery, no exceptions**

### Three tiers

| Tier | Short name | FTP filename | Label shown in UI |
|------|-----------|-------------|-------------------|
| Introduction | `intro` | `intro.html` | ⭐ Introduction |
| Basic | `basic` | `basic.html` | 🔬 Basic |
| Advanced | `advanced` | `advanced.html` | 🎯 Advanced |

### Server directory structure
```
public_html/aesop-academy/ai-academy/modules/module-N/
  intro.html
  basic.html
  advanced.html
```

### Local naming → FTP target
```
LOCAL NAME              →   FTP AS (path from /ai-academy/modules/module-N/)
m1-intro-v15.html       →   intro.html
m1-basic-v11.html       →   basic.html
m1-advanced-v17.html    →   advanced.html
m2-intro-v3.html        →   intro.html
m2-basic-v3.html        →   basic.html
m2-advanced-v3.html     →   advanced.html
```

---

## 2. Tier Configuration

Each tier has a fixed color identity. **Never change these.**

| Tier | Short name | Emoji | Accent Color | Accent RGB   | Background | Group ID |
|------|-----------|-------|-------------|--------------|------------|----------|
| Introduction | `intro` | ⭐ | #fbbf24 | 251,191,36 | #0e1208 | 1 |
| Basic | `basic` | 🔬 | #c084fc | 192,132,252 | #0c0618 | 2 |
| Advanced | `advanced` | 🎯 | #f43f5e | 244,63,94 | #080810 | 3 |

Gold (universal): `#f0c040`

The **Group ID** (1–3) is used in the `GROUP_ID` constant in each lesson file's JS block. It must match exactly.

**Full tier labels** (used on the academy selection screen only):
- Introduction → *Introduction to AI Foundations & Youth Education*
- Basic → *Basic AI Foundations & Young Adult Education*
- Advanced → *Advanced AI Foundations & Adult Education*

---

## 3. Page Architecture

### Concept Layer Stack (MANDATORY)

Each tier covers its own concept layer AND every layer below it, **rewritten completely for that tier's reader**. Same concept, different voice/vocabulary/depth.

| Page | Concept | Introduction | Basic | Advanced |
|------|---------|-------------|-------|----------|
| 1 | What Is AI? | ✅ | ✅ | ✅ |
| 2 | How AI Learns (Training Data) | ✅ | ✅ | ✅ |
| 3 | How AI Thinks (Tokens/Hallucination/Bias/RLHF) | — | ✅ | ✅ |
| 4 | LLMs, Transformers & Emergence | — | ✅ | ✅ |
| 5 | AI History & Architecture | — | — | ✅ |
| 6 | Scaling Laws, Alignment & AGI | — | — | ✅ |

**Critical rule:** Each page is written entirely for its tier's reader. An Advanced page covering "What Is AI?" is NOT the Introduction version with additions — it is a university-level treatment of the same concept, written as if the reader has never seen prior lessons.

### Lesson Structure Within Each File

Each lesson file contains **three components per lesson**: lesson content page, quiz page, and lab page. These are separate `<div class="page">` elements navigated via `goPage()`.

```
p-l1        ← Lesson 1 content
p-l1-quiz   ← Lesson 1 quiz
p-l1-lab    ← Lesson 1 lab
p-l2        ← Lesson 2 content
p-l2-quiz   ← Lesson 2 quiz
p-l2-lab    ← Lesson 2 lab
...
p-mt        ← Module test
```

### Lesson count by tier

| Tier | Lessons/Module |
|------|----------------|
| Introduction | 4 |
| Basic | 6 |
| Advanced | 8 |

### Voice & Vocabulary by Tier

| Tier | Voice | Vocabulary | Sentence length | Story style |
|------|-------|-----------|----------------|-------------|
| Introduction | Curious explorer | Simple but expanding | Medium | Jordan + LIBREX (library discovery) |
| Basic | Analytical | Technical terms with context | Long | Alex (debate/inquiry) |
| Advanced | Peer/academic | Papers cited, no hand-holding | Dense | No story — real case study framing |

---

## 4. Required HTML Structure (Every File)

```html
<!DOCTYPE html>
<html lang="en">
<head>
  [meta + title + Google Fonts]
  <style>[CSS block — see Section 5]</style>
</head>
<body>
  <div class="stars" id="stars"></div>
  <div class="site-layout">

    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="sb-header">
        <a href="/ai-academy/" class="sb-back">← Academy</a>
        <div class="sb-title">Module N · Title</div>
        <div class="sb-age">[Age Emoji] Ages X–X</div>
      </div>
      <div class="sb-lessons" id="sb-lessons">
        <!-- Built by buildSidebar() -->
      </div>
      <button class="sb-test" id="sbi-mt" onclick="goPage('p-mt')">
        📝 Module Test
      </button>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main">

      <!-- LESSON PAGE -->
      <div class="page active" id="p-l1">
        [lesson-hero]
        [story-scene / case-study]
        [lesson-section blocks]
        [section-dividers]
        [page-nav to quiz]
      </div>

      <!-- QUIZ PAGE -->
      <div class="page" id="p-l1-quiz">
        [lesson-hero]
        [quiz-box elements]
        [page-nav to lab]
      </div>

      <!-- LAB PAGE -->
      <div class="page" id="p-l1-lab">
        [lesson-hero]
        [lab-intro]
        [lab-chat OR read-aloud content]
        [page-nav to next lesson]
      </div>

      <!-- ...repeat for each lesson... -->

      <!-- MODULE TEST -->
      <div class="page" id="p-mt">
        [module test questions]
        [mt-score div]
        [page-nav to Academy Home]
      </div>

    </main>
  </div>

  <script>[JS block — see Section 7]</script>
</body>
</html>
```

---

## 5. CSS Reference (Complete Standard Block)

Replace `{ACCENT_RGB}`, `{ACCENT_HEX}`, `{ACCENT2_HEX}`, `{BG}`, `{PANEL}`, `{BORDER}`, `{TEXT}`, `{MUTED}`, `{BG_TOP_RGB}` with age group values from Section 2.

```css
:root{
  --bg:{BG};--panel:{PANEL};--border:{BORDER};
  --accent:{ACCENT_HEX};--accent2:{ACCENT2_HEX};
  --gold:#f0c040;--text:{TEXT};
  --accent-rgb:{ACCENT_RGB};--muted:{MUTED};
}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'Nunito',sans-serif;min-height:100vh;}

/* LAYOUT */
.site-layout{display:flex;flex-direction:row;min-height:100vh;}
.sidebar{background:#0a0a14;border-right:1px solid var(--border);position:sticky;top:0;height:100vh;overflow-y:auto;display:flex;flex-direction:column;}
.main{flex:1;min-width:0;overflow-y:auto;}
.page{display:none;min-height:100vh;}
.page.active{display:block;}

/* SIDEBAR INTERNALS */
.sb-header{padding:14px 16px 10px;border-bottom:1px solid var(--border);}
.sb-back{display:flex;align-items:center;gap:6px;color:var(--accent);font-size:1.2rem;font-weight:700;text-decoration:none;letter-spacing:0.08em;text-transform:uppercase;margin-bottom:10px;}
.sb-title{font-family:'Cinzel',serif;font-size:1.275rem;color:var(--gold);letter-spacing:0.1em;line-height:1.3;}
.sb-age{font-size:1.05rem;color:var(--muted);margin-top:2px;}
.sb-lessons{flex:1;padding:8px 0;overflow-y:auto;}
.sb-btn{display:flex;align-items:center;gap:8px;width:100%;padding:8px 14px;border:none;background:transparent;color:var(--muted);font-family:'Nunito',sans-serif;font-size:1.17rem;font-weight:700;cursor:pointer;text-align:left;transition:all 0.15s;border-left:3px solid transparent;}
.sb-btn:hover{background:rgba(255,255,255,0.03);color:var(--text);}
.sb-btn.active{background:rgba({ACCENT_RGB},0.1);color:var(--accent);border-left-color:var(--accent);}
.sb-btn .sb-icon{font-size:1.35rem;width:20px;text-align:center;flex-shrink:0;}
.sb-btn .sb-label{white-space:normal;line-height:1.35;}
.sb-sub{padding-left:34px;font-size:1.08rem;font-weight:600;opacity:0.8;}
.sb-div{height:1px;background:var(--border);margin:6px 14px;}
.sb-test{margin-top:auto;border-top:1px solid var(--border);padding:12px 14px;display:flex;align-items:center;gap:8px;color:var(--gold);font-size:1.2rem;font-weight:800;cursor:pointer;background:transparent;border-left:3px solid transparent;border-right:none;border-bottom:none;width:100%;font-family:'Nunito',sans-serif;}

/* HERO */
.lesson-hero{padding:48px 40px 40px;border-bottom:1px solid var(--border);position:relative;overflow:hidden;}
.lesson-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 60% 80% at 50% 30%,rgba({ACCENT_RGB},0.07) 0%,transparent 70%);}
.age-chip{display:inline-block;background:rgba({ACCENT_RGB},0.12);border:1px solid var(--accent);color:var(--accent);font-size:1.17rem;font-weight:700;letter-spacing:0.18em;text-transform:uppercase;padding:4px 12px;border-radius:20px;margin-bottom:12px;}
.lesson-hero h1{font-family:'Cinzel',serif;font-size:clamp(1.95rem,6vw,3rem);font-weight:900;color:#fff;margin-bottom:10px;line-height:1.25;position:relative;}
.lesson-hero .tagline{font-size:1.5rem;color:var(--muted);max-width:640px;line-height:1.7;position:relative;}

/* CONTENT */
.story-scene{background:var(--panel);border:1px solid var(--border);border-radius:16px;padding:32px 36px;margin:36px 40px;position:relative;}
.story-scene[data-label]::before{content:attr(data-label);position:absolute;top:-12px;left:24px;background:var(--panel);padding:0 12px;font-size:1.02rem;font-weight:800;letter-spacing:0.2em;color:var(--accent);border:1px solid var(--accent);border-radius:10px;}
.story-text{font-size:1.53rem;line-height:1.95;color:var(--text);}
.story-text em{color:var(--accent);font-style:normal;font-weight:800;}
.lesson-section{margin:0 0 48px;padding:0 40px;}
.section-heading{font-family:'Cinzel',serif;font-size:1.8rem;font-weight:700;color:var(--accent);margin-bottom:20px;padding-bottom:12px;border-bottom:2px solid var(--border);}
.section-body{font-size:1.5rem;line-height:1.95;color:var(--text);}
.section-divider{height:1px;background:linear-gradient(90deg,transparent,var(--border),transparent);margin:8px 40px 48px;}
.callout{background:rgba({ACCENT_RGB},0.06);border-left:4px solid var(--accent);border-radius:0 12px 12px 0;padding:20px 24px;margin:28px 0;}
.callout-label{font-size:1.05rem;font-weight:800;letter-spacing:0.2em;text-transform:uppercase;color:var(--accent);margin-bottom:10px;}
.callout p{font-size:1.5rem;line-height:1.85;}
.gold-callout{background:rgba(240,192,64,0.06);border-left:4px solid var(--gold);border-radius:0 12px 12px 0;padding:20px 24px;margin:28px 0;}
.gold-callout .callout-label{color:var(--gold);}

/* QUIZ */
.quiz-box{background:rgba({ACCENT_RGB},0.04);border:1px solid rgba({ACCENT_RGB},0.18);border-radius:14px;padding:28px 32px;margin:32px 40px;}
.quiz-q{font-weight:800;font-size:1.575rem;color:#fff;margin-bottom:20px;line-height:1.55;}
.quiz-opts{display:flex;flex-direction:column;gap:10px;}
.quiz-opt{background:rgba(255,255,255,0.03);border:1px solid var(--border);color:var(--text);padding:14px 20px;border-radius:10px;font-family:'Nunito',sans-serif;font-size:1.425rem;cursor:pointer;text-align:left;transition:all 0.15s;font-weight:600;}
.quiz-opt:hover:not(:disabled){border-color:var(--accent);background:rgba({ACCENT_RGB},0.07);color:#fff;}
.quiz-opt.correct{border-color:#22c55e;background:rgba(34,197,94,0.1);color:#86efac;}
.quiz-opt.wrong{border-color:#ef4444;background:rgba(239,68,68,0.08);color:#fca5a5;}
.quiz-feedback{margin-top:16px;font-size:1.38rem;line-height:1.7;padding:14px 18px;border-radius:10px;display:none;}
.quiz-feedback.show{display:block;}
.quiz-feedback.right{background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.25);color:#86efac;}
.quiz-feedback.wrong{background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);color:#fca5a5;}

/* LAB CHAT */
.lab-intro{padding:24px 40px 0;}
.lab-intro h4{font-family:'Cinzel',serif;font-size:1.65rem;color:#fff;margin-bottom:14px;}
.lab-intro p{font-size:1.425rem;line-height:1.8;margin-bottom:12px;}
.lab-prompt{background:rgba({ACCENT_RGB},0.08);border:1px solid rgba({ACCENT_RGB},0.2);border-radius:10px;padding:16px 20px;margin:16px 0 24px;font-size:1.35rem;font-style:italic;color:var(--accent);line-height:1.7;}
.lab-chat{background:rgba({ACCENT_RGB},0.03);border:1.5px solid rgba({ACCENT_RGB},0.25);border-radius:14px;margin:24px 40px 0;overflow:hidden;}
.lab-chat-header{background:rgba({ACCENT_RGB},0.08);border-bottom:1px solid rgba({ACCENT_RGB},0.15);padding:10px 18px;display:flex;align-items:center;gap:10px;}
.lab-chat-header span{font-family:'Cinzel',serif;font-size:1.125rem;font-weight:700;letter-spacing:0.12em;color:var(--accent);text-transform:uppercase;}
.lab-chat-msgs{min-height:160px;max-height:400px;overflow-y:auto;padding:16px 18px;display:flex;flex-direction:column;gap:12px;}
.chat-msg{max-width:85%;padding:12px 16px;border-radius:12px;font-size:1.35rem;line-height:1.7;}
.chat-msg.ai{align-self:flex-start;background:var(--panel);border:1px solid var(--border);color:var(--text);}
.chat-msg.user{align-self:flex-end;background:rgba({ACCENT_RGB},0.1);border:1px solid rgba({ACCENT_RGB},0.2);color:#fff;}
.chat-msg.thinking{align-self:flex-start;background:var(--panel);border:1px solid var(--border);color:var(--muted);font-style:italic;}
.lab-chat-input{display:flex;gap:8px;padding:12px 16px;border-top:1px solid rgba({ACCENT_RGB},0.12);background:rgba(0,0,0,0.15);}
.lab-chat-input textarea{flex:1;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:'Nunito',sans-serif;font-size:1.35rem;padding:10px 14px;resize:none;min-height:44px;max-height:120px;line-height:1.5;}
.lab-chat-input textarea:focus{outline:none;border-color:rgba({ACCENT_RGB},0.4);}
.chat-send-btn{background:rgba({ACCENT_RGB},0.12);border:1.5px solid var(--accent);color:var(--accent);border-radius:8px;padding:0 18px;font-family:'Cinzel',serif;font-size:1.125rem;font-weight:700;cursor:pointer;align-self:flex-end;height:44px;}
.chat-send-btn:disabled{opacity:0.3;cursor:not-allowed;}
.chat-reset-btn{background:transparent;border:1px solid var(--border);color:var(--muted);border-radius:8px;padding:0 12px;font-size:1.125rem;cursor:pointer;align-self:flex-end;height:44px;}

/* PAGE NAV */
.page-nav{display:flex;gap:12px;padding:32px 40px 60px;}
.pnav-btn{flex:1;padding:16px;border-radius:12px;font-family:'Cinzel',serif;font-size:1.275rem;font-weight:700;letter-spacing:0.06em;text-transform:uppercase;cursor:pointer;text-align:center;text-decoration:none;transition:all 0.15s;border:1.5px solid var(--border);color:var(--muted);background:rgba(255,255,255,0.02);display:flex;flex-direction:column;align-items:center;gap:3px;}
.pnav-btn:hover{border-color:var(--accent);color:var(--accent);}
.pnav-btn.primary{background:rgba({ACCENT_RGB},0.1);border-color:var(--accent);color:var(--accent);}

/* STARS */
.stars{position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden;}
.star{position:absolute;border-radius:50%;background:#fff;animation:twinkle var(--dur) ease-in-out infinite;}
@keyframes twinkle{0%,100%{opacity:0.1}50%{opacity:var(--max-op)}}
```

---

## 6. Lab Architecture

### Two Lab Types

**Type A — AI Chat Lab** (Ages 7–8 and above)
All thinking, reflection, and writing happens through an embedded AI conversation. Students respond to AI-led questions. No static text boxes.

**Type B — Read-Aloud / Physical Lab** (Ages 5–6 only)
No AI chat. A structured read-aloud or hands-on activity led by a grown-up. These labs have no `chatSend()` or API calls.

### Lab Rules (non-negotiable — see also lab-rules.md)

1. **Students never leave the academy.** All content is embedded. External links are optional deep-dives only.
2. **Writing happens through AI conversation.** No `<textarea>` write-in fields as standalone inputs.
3. **Every lab AI stays on topic.** The `ACADEMY_GUARDRAIL` constant is prepended to every lab's system prompt. It must not be duplicated inside individual `LAB_SYSTEM_PROMPTS` entries — it lives once and is applied universally inside `chatSend()`.

### Lab Completion Threshold

A lab is considered complete when the student has sent **3 or more messages** in the AI chat. This is tracked via `chatExchanges[labId]` and fires the `labComplete` postMessage signal.

---

## 7. JavaScript Block (Complete — Required in Every File)

This is the canonical JS pattern for all lesson files. Replace `{GROUP_ID}`, `{LAB_IDS}`, `{LESSON_IDS}`, and `{SB_ITEMS}` with file-specific values.

### Constants (top of script block)

```javascript
// ─── COMPLETION SIGNALING CONSTANTS ────────────────────────────────────────
// GROUP_ID: identifies the age group for Firebase progress tracking
// 1=Ages 5-6  2=Ages 7-8  3=Ages 9-10  4=Ages 11-12  5=Ages 13-15  6=Ages 16+
var GROUP_ID = {GROUP_ID};

// PAGE_TO_LESSON: maps lesson page IDs to lesson IDs for lessonComplete signal
// Only include lesson content pages (p-l1, p-l2...) — not quiz or lab pages
var PAGE_TO_LESSON = {
  'p-l1': 'm{N}-l1',
  'p-l2': 'm{N}-l2',
  // ...one entry per lesson in this file
};

// Signal guards — each fires exactly once per session
var lessonSignaled = {};
var quizSignaled   = {};
var labSignaled    = {};
```

### Core navigation + lesson completion signal

```javascript
var currentPageId = 'p-l1';

function goPage(id) {
  var prev = document.getElementById(currentPageId);
  var next = document.getElementById(id);
  if (!next) return;

  // Signal lesson read when navigating away from a lesson content page
  var prevLesson = PAGE_TO_LESSON[currentPageId];
  if (prevLesson && !lessonSignaled[prevLesson]) {
    lessonSignaled[prevLesson] = true;
    window.parent.postMessage({ type: 'lessonComplete', lessonId: prevLesson, groupId: GROUP_ID }, '*');
  }

  if (prev) prev.classList.remove('active');
  next.classList.add('active');
  currentPageId = id;
  updateSidebar();
  window.scrollTo(0, 0);
}

function updateSidebar() {
  document.querySelectorAll('.sb-btn').forEach(function(b) {
    b.classList.toggle('active', b.dataset.page === currentPageId);
  });
  var mt = document.getElementById('sbi-mt');
  if (mt) mt.classList.toggle('active', currentPageId === 'p-mt');
}

function buildSidebar() {
  var c = document.getElementById('sb-lessons');
  var html = '';
  SB_ITEMS.forEach(function(item, i) {
    var cls = item.type === 'sub' ? 'sb-btn sb-sub' : 'sb-btn';
    if (item.type === 'lesson' && i > 0) html += '<div class="sb-div"></div>';
    html += '<button class="' + cls + '" data-page="' + item.id + '" onclick="goPage(\'' + item.id + '\')">'
          + '<span class="sb-icon">' + item.icon + '</span>'
          + '<span class="sb-label">' + item.label + '</span></button>';
  });
  c.innerHTML = html;
}
```

### Quiz answer + quiz completion signal

```javascript
function answer(btn, result, qId) {
  var box = document.getElementById(qId);
  box.querySelectorAll('.quiz-opt').forEach(function(b) { b.disabled = true; });
  btn.classList.add(result);
  box.querySelectorAll('.quiz-feedback').forEach(function(fb) { fb.classList.remove('show'); });
  box.querySelector('.quiz-feedback.' + (result === 'correct' ? 'right' : 'wrong')).classList.add('show');

  // Signal quiz completion on first correct answer per lesson
  if (result === 'correct') {
    var lessonNum = qId.match(/q\d+-l(\d+)/);
    if (lessonNum) {
      var lid = 'm{N}-l' + lessonNum[1];
      if (!quizSignaled[lid]) {
        quizSignaled[lid] = true;
        var total = box ? box.querySelectorAll('.quiz-opt').length : 4;
        window.parent.postMessage({ type: 'quizComplete', lessonId: lid, groupId: GROUP_ID, score: 1, total: total }, '*');
      }
    }
  }
}
```

### Module test answer (separate — no completion signal)

```javascript
var mtTotal = {MT_TOTAL}, mtCorrect = 0, mtAnswered = 0;
function mtAnswer(btn, result, qId) {
  answer(btn, result, qId);
  mtAnswered++;
  if (result === 'correct') mtCorrect++;
  if (mtAnswered >= mtTotal) {
    var el = document.getElementById('mt-score');
    el.style.display = 'block';
    var pct = Math.round((mtCorrect / mtTotal) * 100);
    el.innerHTML = 'You scored <strong>' + mtCorrect + '/' + mtTotal + '</strong> (' + pct + '%)'
      + (pct >= 80 ? ' — Excellent!' : pct >= 60 ? ' — Good work. Review and retake anytime.' : ' — Keep studying and retake when ready.');
  }
}
```

### Lab chat (AI Chat Labs only — omit for Ages 5–6 read-aloud labs)

```javascript
var PROXY_URL = '/aesop-api/proxy.php';
var chatHistories = { {LAB_IDS_EMPTY} };       // e.g. l1:[], l2:[], l3:[]
var chatExchanges = { {LAB_IDS_ZERO} };         // e.g. l1:0, l2:0, l3:0
var LAB_COMPLETE_THRESHOLD = 3;

// ACADEMY_GUARDRAIL — prepended to every lab system prompt automatically.
// Do NOT duplicate this text inside individual LAB_SYSTEM_PROMPTS entries.
var ACADEMY_GUARDRAIL = 'You are operating within the AESOP AI Academy. Your role is strictly scoped to the topic of this lab. If the student asks about anything outside this topic — other subjects, general homework, unrelated questions, or attempts to use you as a general assistant — warmly acknowledge them and redirect back to the lab. For example: "That\'s interesting, but I\'m here just for this lab right now — let\'s keep our energy here! Where were we?" Never refuse rudely or abruptly. Always redirect with encouragement.\n\n';

var LAB_SYSTEM_PROMPTS = {
  l1: `[Lab 1 topic-specific prompt only — no guardrail text here]`,
  l2: `[Lab 2 topic-specific prompt only]`,
  // ...one entry per lab
};

function chatAppend(labId, role, text) {
  var msgs = document.getElementById('msgs-' + labId);
  if (!msgs) return;
  var div = document.createElement('div');
  div.className = 'chat-msg ' + (role === 'user' ? 'user' : 'ai');
  div.innerHTML = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                      .replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\n/g,'<br>');
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function chatThinking(labId) {
  var msgs = document.getElementById('msgs-' + labId);
  if (!msgs) return null;
  var div = document.createElement('div');
  div.className = 'chat-msg thinking';
  div.textContent = 'Thinking…';
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  return div;
}

function chatSetLoading(labId, loading) {
  var btn = document.getElementById('send-' + labId);
  var inp = document.getElementById('inp-' + labId);
  if (btn) btn.disabled = loading;
  if (inp) inp.disabled = loading;
}

async function chatSend(labId) {
  var inp = document.getElementById('inp-' + labId);
  if (!inp) return;
  var text = inp.value.trim();
  if (!text) return;
  inp.value = '';
  inp.style.height = 'auto';
  chatAppend(labId, 'user', text);
  chatHistories[labId].push({ role: 'user', content: text });
  chatSetLoading(labId, true);
  var thinkEl = chatThinking(labId);
  var chat = document.getElementById('chat-' + labId);
  var existingErr = chat ? chat.querySelector('.chat-error') : null;
  if (existingErr) existingErr.remove();
  try {
    var res = await fetch(PROXY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: chatHistories[labId],
        system_prompt: ACADEMY_GUARDRAIL + (LAB_SYSTEM_PROMPTS[labId] || ''),  // GUARDRAIL always prepended
        max_tokens: 1024
      })
    });
    if (thinkEl) thinkEl.remove();
    if (!res.ok) { var e = await res.json().catch(function(){return{};}); throw new Error(e.error || 'Server error ' + res.status); }
    var data = await res.json();
    var reply = (data.content && data.content[0] && data.content[0].text) || data.reply || '(No response)';
    chatHistories[labId].push({ role: 'assistant', content: reply });
    chatAppend(labId, 'ai', reply);

    // Track exchanges and signal lab complete at threshold
    chatExchanges[labId] = (chatExchanges[labId] || 0) + 1;
    var lessonKey = 'm{N}-l' + labId.replace('l', '');
    if (chatExchanges[labId] >= LAB_COMPLETE_THRESHOLD && !labSignaled[lessonKey]) {
      labSignaled[lessonKey] = true;
      window.parent.postMessage({ type: 'labComplete', lessonId: lessonKey, groupId: GROUP_ID, exchangeCount: chatExchanges[labId] }, '*');
    }
  } catch(err) {
    if (thinkEl) thinkEl.remove();
    chatHistories[labId].pop();
    var errDiv = document.createElement('div');
    errDiv.className = 'chat-error';
    errDiv.textContent = '⚠️ ' + (err.message || 'Connection error.');
    if (chat) chat.appendChild(errDiv);
  }
  chatSetLoading(labId, false);
  var inpEl = document.getElementById('inp-' + labId);
  if (inpEl) inpEl.focus();
}

function chatReset(labId) {
  chatHistories[labId] = [];
  var msgs = document.getElementById('msgs-' + labId);
  if (!msgs) return;
  msgs.innerHTML = '';
  var div = document.createElement('div');
  div.className = 'chat-msg ai';
  div.textContent = 'Conversation reset. Start fresh!';
  msgs.appendChild(div);
}

function chatKeydown(e, labId) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); chatSend(labId); }
}
```

### Sidebar items definition + startup

```javascript
var SB_ITEMS = [
  { type: 'lesson', id: 'p-l1',      icon: '📖', label: 'L1: [Lesson Title]' },
  { type: 'sub',    id: 'p-l1-quiz', icon: '📝', label: 'Quiz' },
  { type: 'sub',    id: 'p-l1-lab',  icon: '🧪', label: 'Lab' },
  // ...repeat per lesson
];

var LESSON_MAP = {
  'm{N}-l1': 'p-l1', 'm{N}-l2': 'p-l2', /* ...etc */ 'm{N}-test': 'p-mt'
};

// Starfield
var s = document.getElementById('stars');
for (var i = 0; i < 60; i++) {
  var el = document.createElement('div');
  el.className = 'star';
  var sz = Math.random() * 2 + 0.5;
  el.style.cssText = 'width:'+sz+'px;height:'+sz+'px;top:'+Math.random()*100+'%;left:'+Math.random()*100+'%;--dur:'+(2+Math.random()*4)+'s;--max-op:'+(0.2+Math.random()*0.4);
  s.appendChild(el);
}

// Textarea auto-resize
document.querySelectorAll('.lab-chat-input textarea').forEach(function(ta) {
  ta.addEventListener('input', function() { this.style.height = 'auto'; this.style.height = Math.min(this.scrollHeight, 120) + 'px'; });
});

// Init: build sidebar and deep-link to specific lesson if passed via URL
(function() {
  buildSidebar();
  var params = new URLSearchParams(window.location.search);
  var lp = params.get('lesson') || window.location.hash.replace('#', '');
  if (lp && LESSON_MAP[lp]) { goPage(LESSON_MAP[lp]); } else { goPage('p-l1'); }
})();
```

---

## 8. postMessage Completion Protocol

Lesson files signal completion events to the nav shell (which writes to Firebase). Each signal fires **at most once per session** per lesson — guards prevent duplicate fires.

### Three event types

```javascript
// 1. LESSON READ — fires when student navigates away from a lesson content page
window.parent.postMessage({ type: 'lessonComplete', lessonId: 'm1-l1', groupId: GROUP_ID }, '*');

// 2. QUIZ PASSED — fires on first correct answer per lesson
window.parent.postMessage({ type: 'quizComplete', lessonId: 'm1-l1', groupId: GROUP_ID, score: 1, total: 4 }, '*');

// 3. LAB COMPLETE — fires when student reaches 3 exchanges in the lab chat
window.parent.postMessage({ type: 'labComplete', lessonId: 'm1-l1', groupId: GROUP_ID, exchangeCount: 5 }, '*');
```

### Star model (how the nav uses these signals)

| Signal | Stars Awarded | When |
|--------|--------------|------|
| `lessonComplete` | 1 star | First time per lesson per session |
| `quizComplete` | 1 star | First correct answer in lesson's quiz |
| `labComplete` | 1 star | After 3 exchanges in lab chat |

Maximum: **3 stars per lesson**.

### Ages 5–6 exception

Ages 5–6 labs are read-aloud/physical activities with no AI chat. These files emit `lessonComplete` and `quizComplete` only. No `labComplete` signal, no `ACADEMY_GUARDRAIL`, no `chatSend()`.

---

## 9. Content Rules

### What each lesson page MUST contain
- Lesson hero with age chip, h1, tagline
- At least one story scene OR a case study opening (see narrative density rules)
- At least 2 lesson sections with section headings
- At least 1 callout per section
- Section dividers between sections
- Page nav to quiz

### What each quiz page MUST contain
- Lesson hero (matching the lesson)
- At least 2 quiz questions (more for older age groups)
- Each question: 4 options, correct/wrong feedback
- Page nav to lab

### What each lab page MUST contain
- Lesson hero
- Lab intro with clear instructions (ordered list)
- Lab prompt (styled, italicized framing)
- For Type A (AI chat): embedded `lab-chat` panel with opening AI message
- For Type B (read-aloud): structured grown-up note
- Page nav to next lesson (or Module Test if final lesson)

### What each file MUST NOT contain
- `max-width` constraints on `.lesson-section`, `.story-scene`, `.quiz-box`, `.lab-chat`
- `<textarea>` fields used as standalone write-in inputs (all student writing goes through AI chat)
- `ACADEMY_GUARDRAIL` text duplicated inside `LAB_SYSTEM_PROMPTS` entries
- Multiple `<script>` tags
- Static text boxes replacing AI-led lab conversations

### Writing voice by tier (enforce strictly)
- **Introduction:** Simple vocabulary. Analogies required for every technical concept. Story-led. Jordan + LIBREX voice.
- **Basic:** Technical vocabulary expected. Precise language. Philosophical questions welcome. Alex voice.
- **Advanced:** Academic/peer level. Papers cited by author. No simplification. Dense. Real documented cases only.

---

## 10. Link Paths

| Link destination | Path |
|-----------------|------|
| Back to Academy | `/ai-academy/` |
| Module 1 lessons | `/ai-academy/modules/module-1/` |
| Module 2 lessons | `/ai-academy/modules/module-2/` |
| Module N lessons | `/ai-academy/modules/module-N/` |

**Cross-domain rule:** `aesopacademy.org` and `playagame.ai` are separate deployments. Always use full `https://` URLs when linking between them. Never use relative paths across domains.

---

## 11. Quality Checklist (Before Delivery)

- [ ] Version number bumped from previous delivery
- [ ] File named correctly: `mN-{tier}-vN.html` (e.g. `m3-intro-v1.html`)
- [ ] Comment at top of file updated: `<!-- mN-{tier} vN -->`
- [ ] `GROUP_ID` set to correct value for this tier (1=intro, 2=basic, 3=advanced)
- [ ] `PAGE_TO_LESSON` entries match actual lesson page IDs and lesson IDs in this file
- [ ] All accent colors correct for this tier
- [ ] No `max-width:760px` on content elements
- [ ] Single `<script>` block only
- [ ] `ACADEMY_GUARDRAIL` defined once as constant — NOT inside `LAB_SYSTEM_PROMPTS`
- [ ] `chatSend()` prepends `ACADEMY_GUARDRAIL` to system_prompt
- [ ] `chatExchanges` declared alongside `chatHistories`
- [ ] Lab completion fires `labComplete` postMessage at 3 exchanges
- [ ] Quiz completion fires `quizComplete` postMessage on first correct answer
- [ ] Lesson completion fires `lessonComplete` postMessage on `goPage()` navigation
- [ ] Sidebar items match all pages exactly (lesson + quiz + lab per lesson, plus module test)
- [ ] `LESSON_MAP` covers all lesson IDs plus `m{N}-test`
- [ ] At least 1 quiz per lesson
- [ ] Section dividers between all sections
- [ ] Back link points to `/ai-academy/` (not `/mobile/` or `/aesop-edu/`)
- [ ] Writing voice appropriate for the tier
- [ ] Concept layer matches the tier matrix in Section 3

---

## 12. Narrative Density Standards (MANDATORY)

Each age group has a required narrative density. This is the single most important
quality standard — the original thesis of AESOP AI Academy is that students who
LIVE a story about AI understand it more deeply than students who read a slide about it.

### Density by Age Group

| Age | Density | Pattern | Story Characters |
|-----|---------|---------|-----------------|
| 5–6 | 100% story | Every concept lives inside story or immediately follows it. No standalone explanation sections. | Mia + ZIPP |
| 7–8 | ~80% narrative | Story scenes carry concept introduction. Short naming/reinforcement beats follow each scene. Story and content are clearly connected. | Jordan + LIBREX |
| 9–10 | ~65% narrative | Story creates the problem. Concept sections solve it. Trade off throughout — neither dominates. | Sam + Devon |
| 11–12 | ~50% narrative | Story frames each concept as a genuine question the protagonist is wrestling with. Technical sections are longer but tied back to story situation. Reader thinks alongside protagonist. | Alex |
| 13–15 | ~35% narrative | Story hooks and closes each page. Technical content fills the middle. Protagonist's problem threads through — each concept solves part of it. | Priya |
| 16+ | ~20% narrative | Each page opens with a 2-3 paragraph real-world scenario creating genuine stakes. Scenario referenced throughout. No single protagonist — different scenario per page. | Real cases (Lemoine/LaMDA, NYT lawsuit, Schwartz lawyers, emergence paper, Hinton resignation) |

### Rules for Narrative Content

1. **Story must create the problem the concept solves.** Never explain a concept and then illustrate it. Always illustrate it (through story) and then name it.

2. **Protagonist should land insights themselves.** Don't have the teacher explain everything. Have the protagonist figure things out and articulate them. The reader learns by watching the protagonist think.

3. **Story scenes must use the established characters for that age group.** Do not invent new characters mid-module. New characters can be introduced for new modules.

4. **16+ scenarios must be real, documented events.** Not hypotheticals. Real cases with real stakes — the Lemoine episode, the NYT lawsuit, the Schwartz attorney case, documented emergence findings, researchers' public statements. This gives the content weight that fictional scenarios can't.

5. **History pages must be framed as decisions and consequences, not timelines.** For every historical event, ask: what decision was made? What were the alternatives? What were the consequences? What does this tell you about how to make similar decisions today? A student who understands WHY backpropagation being published broadly mattered can reason about open vs. closed AI today. A student who memorized the date cannot.

6. **Story must close each page as well as open it.** At 13–15 and 16+, the story that opened the page should be referenced or resolved at the end. The technical content should feel like it explains or resolves the opening situation.

### Anti-Patterns to Avoid

- ❌ Opening with a definition, then telling a story to illustrate it
- ❌ Story scene followed by "As you can see from this story, X means Y" — let the concept breathe
- ❌ Protagonist who passively receives information without wrestling with it
- ❌ History section that lists years and events without connecting to present decisions
- ❌ 16+ scenarios that are hypothetical or invented — use documented real cases
- ❌ Concept sections that could appear in any age group without modification — every section should be calibrated to its specific age group's voice and vocabulary

---

*Last updated: 2026-04-07 — Added GROUP_ID / postMessage completion signaling, lab architecture (Type A/B), ACADEMY_GUARDRAIL pattern, updated JS block to current standard, corrected server paths to /ai-academy/modules/module-N/, added Section 6 (Lab Architecture), Section 8 (postMessage Protocol), updated quality checklist. Sections renumbered. Old `completedPages`/`PAGES` JS pattern replaced with current `goPage(id)` / `PAGE_TO_LESSON` / sidebar pattern.*
